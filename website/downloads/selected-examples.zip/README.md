# Selected BenchForge examples

This archive contains 33 selected Offline EQA records (six each from ALFRED, Habitat, LIBERO, TartanGround, and UAV, and three from CARLA), their display images, and selected fields for two interactive tasks.

The full offline datasets contain 10,000 records each. These files are a small showcase subset.

Each offline record preserves its original ID, Chinese question, choices, and reference answer. English questions and choices are display translations. Image paths are relative to the root of this archive. Display images retain their source content and markings and are resized/encoded as WebP for the website.

Offline records: assets/data/showcase/*.json
Offline image assets: assets/images/showcase/*
Interactive records: examples/interactive-short.json and interactive-long.json

Interactive records contain selected task fields and trajectory checkpoints, not full runnable simulator packages.
